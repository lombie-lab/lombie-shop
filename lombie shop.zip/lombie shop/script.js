// Show login modal when profile icon clicked
document.getElementById("profileBtn").addEventListener("click", () => {
  document.getElementById("loginModal").style.display = "flex";
});

// Buyer login
function loginUser() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!email || password.length !== 4) {
    alert("Please enter a valid email and 4-digit password.");
    return;
  }

  alert("Login successful! Welcome to Lombie Shop.");
  document.getElementById("loginModal").style.display = "none";
}

// Ask owner login
function askOwner() {
  document.getElementById("loginModal").style.display = "none";
  document.getElementById("ownerModal").style.display = "flex";
}

// Owner login step
function confirmOwner(answer) {
  if (answer) {
    const password = prompt("Enter owner password:");
    if (password === "lombie1933") {
      alert("Owner login successful! You can now add products.");
      // In real app, show post/upload page
      document.getElementById("ownerModal").style.display = "none";
    } else {
      alert("Incorrect password. Try again.");
    }
  } else {
    // Back to normal login
    document.getElementById("ownerModal").style.display = "none";
    document.getElementById("loginModal").style.display = "flex";
  }
}

// Buy button logic
function buyNow(productName) {
  const message = encodeURIComponent(`Hi, I want to buy: ${productName}`);
  const telegramUsername = "@sendnow_88";
  window.open(`https://t.me/${telegramUsername}?text=${message}`, "_blank");
}

// Close modal when clicking outside
window.onclick = function(event) {
  const loginModal = document.getElementById("loginModal");
  const ownerModal = document.getElementById("ownerModal");
  if (event.target === loginModal) loginModal.style.display = "none";
  if (event.target === ownerModal) ownerModal.style.display = "none";
}
